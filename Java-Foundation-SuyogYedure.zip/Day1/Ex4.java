class Ex4{
  public static void main(String args[]){
    byte a = 9;
    short b = 23;
    int c = 100;
    long d = 56;
    float f = 2.0f;
    double g = 89.22;
    char h = 'C';
    boolean i = true;

    System.out.println("The byte is : "+a);
    System.out.println("The short is : "+b);
    System.out.println("The int is : "+c);
    System.out.println("The long is : "+d);
    System.out.println("The float is : "+f);
    System.out.println("The double is : "+g);
    System.out.println("The char is : "+h);
    System.out.println("The boolean is : "+i);
    


    
  }
}