class Ex3{
   public static void main(String args[]){

      int a=10,b=20,c=0;
        c = a+b;
        System.out.println("Addition is : "+c);
   }
}